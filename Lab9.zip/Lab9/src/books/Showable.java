package books;

public interface Showable {
    public void show();
}
